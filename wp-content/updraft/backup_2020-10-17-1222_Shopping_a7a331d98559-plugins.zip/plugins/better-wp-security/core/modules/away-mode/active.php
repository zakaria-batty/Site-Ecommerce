<?php

require_once( 'class-itsec-away-mode.php' );
$itsec_away_mode = new ITSEC_Away_Mode();
$itsec_away_mode->run();
