<?php

return [
	'title' => __( 'Hide Backend', 'better-wp-security' ),
];
