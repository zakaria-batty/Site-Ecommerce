<?php

require_once( 'class-itsec-hide-backend.php' );
$itsec_hide_backend = new ITSEC_Hide_Backend();
$itsec_hide_backend->run();
